# Bifurcate Engine Identity Manifest

This folder contains visual identity components for the system:

- `bifurcate_operator_splash.png`: Full symbolic visualization of the Engine in action.
- `bifurcate_sigil.png`: Circular glyph cut from the operator's spiral—use as badge/logo/avatar.
- `favicon.ico`: Small form glyph for browser embedding.
